[Please click here for our changelog.](https://github.com/VSCodeVim/Vim/releases)
